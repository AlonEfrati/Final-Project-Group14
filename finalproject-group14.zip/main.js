angular.module('KRRclass', [ 'chart.js']).controller('MainCtrl', ['$scope','$http', mainCtrl]);

function getCountry(input){
	country = input;
	return country;
};

country = getCountry();
function query1(){
	queryFRA = `PREFIX ft: <http://www.semanticweb.org/jespe/football#> 
	PREFIX spif: <http://spinrdf.org/spif#> 
	PREFIX dbo: <http://dbpedia.org/ontology/> 
	PREFIX dbr: <http://dbpedia.org/resource/> 
	PREFIX dbp: <http://dbpedia.org/property/> 
	PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> 
	PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> 
	PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> 
	PREFIX sesame: <http://www.openrdf.org/schema/sesame#> 
	PREFIX owl: <http://www.w3.org/2002/07/owl#> 
	PREFIX fn: <http://www.w3.org/2005/xpath-functions#> 
	
	SELECT DISTINCT ?leaguelabel ?teamlabel WHERE{
		?x rdf:type ft:FootballLeague;
		   ft:isFootballLeagueOf ?d;
		   rdfs:label ?leaguelabel.
		?d rdf:type ft:Countries;
		   rdfs:label `+'"'+country+'"'+`.
		?j rdf:type ft:FootballClub;
		   ft:competesIn ?x;
		   rdfs:label ?teamlabel.
	}
	`
	return queryFRA
	};

function query2(){
	queryAMS = 
	`PREFIX ft: <http://www.semanticweb.org/jespe/football#> 
	PREFIX spif: <http://spindf.org/spif#> 
	PREFIX dbo: <http://dbpedia.org/ontology/> 
	PREFIX dbr: <http://dbpedia.org/resource/> 
	PREFIX dbp: <http://dbpedia.org/property/> 
	PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> 
	PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> 
	PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> 
	PREFIX sesame: <http://www.openrdf.org/schema/sesame#> 
	PREFIX owl: <http://www.w3.org/2002/07/owl#> 
	PREFIX fn: <http://www.w3.org/2005/xpath-functions#> 

	SELECT ?k ?l WHERE{
    ?x rdf:type ft:Countries;
       rdfs:label `+'"'+country+'"'+`.
    ?h ft:isFootballLeagueOf ?x;
       rdfs:label ?k;
       ft:bestFootballClub ?g.
    ?g rdfs:label ?l.
    
	}`; return queryAMS;
};

function query3(){
queryTUR = 
	`PREFIX ft: <http://www.semanticweb.org/jespe/football#> 
	PREFIX spif: <http://spinrdf.org/spif#> 
	PREFIX dbo: <http://dbpedia.org/ontology/> 
	PREFIX dbr: <http://dbpedia.org/resource/> 
	PREFIX dbp: <http://dbpedia.org/property/> 
	PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> 
	PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> 
	PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> 
	PREFIX sesame: <http://www.openrdf.org/schema/sesame#> 
	PREFIX owl: <http://www.w3.org/2002/07/owl#> 
	PREFIX fn: <http://www.w3.org/2005/xpath-functions#> 

	SELECT ?x WHERE{
    ?p rdf:type ft:Countries;
       rdfs:label `+'"'+country+'"'+`;
       ft:bestDomestClub ?j.
    ?j rdfs:label ?x.
	}`;
	return queryTUR;
};




var endpoint = "http://192.168.178.16:7200/repositories/Final-project";

function mainCtrl($scope, $http){

	$scope.getTeams = function(){
		var newprod = "";
		console.log(query1());
		console.log(country);
		$scope.myDisplayMessage = " You choose to get the football facts of "+country;
		$scope.mySparqlEndpoint = endpoint;
		$scope.mySparqlQuery = encodeURI(query1()).replace(/#/g, '%23');

		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {

			// now iterate on the results
			angular.forEach(data.results.bindings, function(val) {
				newprod += val.teamlabel.value + '<br>';
			league = val.leaguelabel.value;
			document.getElementById("league").innerHTML = league;
			document.getElementById("team").innerHTML = newprod;
			});
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

	};

	$scope.getLeagueTeam = function(){
		var leagueteam = "";
		$scope.mySparqlEndpoint = endpoint;
		$scope.mySparqlQuery = encodeURI(query2()).replace(/#/g, '%23');
		console.log("TEST");
		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {

			// now iterate on the results
			angular.forEach(data.results.bindings, function(val) {
				leagueteam += val.l.value;
			document.getElementById("leagueclub").innerHTML = leagueteam;
			});
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

	};

	$scope.getDomTeam = function(){
		var domestteam = "";
		$scope.mySparqlEndpoint = endpoint;
		$scope.mySparqlQuery = encodeURI(query3()).replace(/#/g, '%23');

		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {
			// now iterate on the results
			document.getElementById("domclub").innerHTML = "No data available!";
			angular.forEach(data.results.bindings, function(val) {
				domestteam += val.x.value + '<br>';
			document.getElementById("domclub").innerHTML = domestteam;
			});
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

	};
	$scope.loadFunctions = function(){
		$scope.getTeams();
		$scope.getLeagueTeam();
		$scope.getDomTeam();

	}

}

