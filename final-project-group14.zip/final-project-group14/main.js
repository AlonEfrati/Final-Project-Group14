angular.module('KRRclass', [ 'chart.js']).controller('MainCtrl', ['$scope','$http', mainCtrl]);

function getCountry(input){
	country = input;
	return country;
};

function getImage() {
	document.getElementById('countryimage').innerHTML = "";
	if (country === "Belgium") {
		document.getElementById('countryimage').innerHTML = '<img src="https://www.gamesatlas.com/images/football/leagues/resized/jupiler-pro-league_320x320.png" width="320px">';
	}
	if (country === "England") {
		document.getElementById('countryimage').innerHTML = '<img src="https://download.logo.wine/logo/Premier_League/Premier_League-Logo.wine.png" width="320px">';
	}
	if (country === "Germany") {
		document.getElementById('countryimage').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/en/thumb/d/df/Bundesliga_logo_%282017%29.svg/1200px-Bundesliga_logo_%282017%29.svg.png" width="320px">';
	}
	if (country === "France") {
		document.getElementById('countryimage').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Ligue1.svg/1200px-Ligue1.svg.png" width="320px">';
	}
	if (country === "Spain") {
		document.getElementById('countryimage').innerHTML = '<img src="https://voetbalwedden.eu/wp-content/uploads/2019/04/la-liga-logo.png" width="320px">';
	}
	if (country === "Italy") {
		document.getElementById('countryimage').innerHTML = '<img src="https://1000logos.net/wp-content/uploads/2018/10/Italian-Serie-A-logo.png" width="320px">';
	}
	if (country === "Scotland") {
		document.getElementById('countryimage').innerHTML = '<img src="https://1000logos.net/wp-content/uploads/2018/10/Scottish-Premier-League-logo.png" width="320px">';
	}
	if (country === "Portugal") {
		document.getElementById('countryimage').innerHTML = '<img src="https://1000marcas.net/wp-content/uploads/2020/03/Portuguese-Primeira-Liga-Logo-1.png" width="320px">';
	}
	if (country === "Poland") {
		document.getElementById('countryimage').innerHTML = '<img src="https://www.thesportsdb.com/images/media/league/badge/l3jovw1516960585.png" width="320px">';
	}
	if (country === "Switzerland") {
		document.getElementById('countryimage').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/en/c/ce/Logo_Raiffeisen_Super_League.png" width="320px">';
	}
	if (country === "Netherlands") {
		document.getElementById('countryimage').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0f/Eredivisie_nieuw_logo_2017-.svg/1200px-Eredivisie_nieuw_logo_2017-.svg.png" width="320px">';
	}
}
function getteamImage() {
	document.getElementById('leagueteam').innerHTML = "";
	if (country === "Belgium") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/en/thumb/7/71/RSC_Anderlecht_logo.svg/1200px-RSC_Anderlecht_logo.svg.png" width="320px">';
	}
	if (country === "England") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://www.voetbalsensatie.nl/wp-content/uploads/2020/02/voetbalreis-manchester-united.png" width="320px">';
	}
	if (country === "Germany") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/FC_Bayern_M%C3%BCnchen_logo_%282017%29.svg/1200px-FC_Bayern_M%C3%BCnchen_logo_%282017%29.svg.png" width="320px">';
	}
	if (country === "France") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Logo_AS_Saint-%C3%89tienne.svg/1200px-Logo_AS_Saint-%C3%89tienne.svg.png" width="320px">';
	}
	if (country === "Spain") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://logos-world.net/wp-content/uploads/2020/06/Real-Madrid-symbol.png" width="320px">';
	}
	if (country === "Italy") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://1000logos.net/wp-content/uploads/2017/03/Juventus-Logo.png" width="320px">';
	}
	if (country === "Scotland") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/en/thumb/3/35/Celtic_FC.svg/1200px-Celtic_FC.svg.png" width="320px">';
	}
	if (country === "Portugal") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/en/thumb/a/a2/SL_Benfica_logo.svg/1200px-SL_Benfica_logo.svg.png" width="320px">';
	}
	if (country === "Poland") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/en/thumb/9/94/Ruch_Chorz%C3%B3w.svg/1024px-Ruch_Chorz%C3%B3w.svg.png" width="320px">';
	}
	if (country === "Switzerland") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://upload.wikimedia.org/wikipedia/en/thumb/8/84/Grasshopper_Club_Z%C3%BCrich_logo.svg/1200px-Grasshopper_Club_Z%C3%BCrich_logo.svg.png" width="320px">';
	}
	if (country === "Netherlands") {
		document.getElementById('leagueteam').innerHTML = '<img src="https://www.cruyff-legacy14krun.nl/files/2019/02/Ajax-logo-COL.png" width="320px">';
	}
}


country = getCountry();
function query1(){
	queryFRA = `PREFIX ft: <http://www.semanticweb.org/jespe/football#> 
	PREFIX spif: <http://spinrdf.org/spif#> 
	PREFIX dbo: <http://dbpedia.org/ontology/> 
	PREFIX dbr: <http://dbpedia.org/resource/> 
	PREFIX dbp: <http://dbpedia.org/property/> 
	PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> 
	PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> 
	PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> 
	PREFIX sesame: <http://www.openrdf.org/schema/sesame#> 
	PREFIX owl: <http://www.w3.org/2002/07/owl#> 
	PREFIX fn: <http://www.w3.org/2005/xpath-functions#> 
	
	SELECT DISTINCT ?leaguelabel ?teamlabel WHERE{
		?x rdf:type ft:FootballLeague;
		   ft:isFootballLeagueOf ?d;
		   rdfs:label ?leaguelabel.
		?d rdf:type ft:Countries;
		   rdfs:label `+'"'+country+'"'+`.
		?j rdf:type ft:FootballClub;
		   ft:competesIn ?x;
		   rdfs:label ?teamlabel.
	}
	`
	return queryFRA
	};

function query2(){
	queryAMS = 
	`PREFIX ft: <http://www.semanticweb.org/jespe/football#> 
	PREFIX spif: <http://spindf.org/spif#> 
	PREFIX dbo: <http://dbpedia.org/ontology/> 
	PREFIX dbr: <http://dbpedia.org/resource/> 
	PREFIX dbp: <http://dbpedia.org/property/> 
	PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> 
	PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> 
	PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> 
	PREFIX sesame: <http://www.openrdf.org/schema/sesame#> 
	PREFIX owl: <http://www.w3.org/2002/07/owl#> 
	PREFIX fn: <http://www.w3.org/2005/xpath-functions#> 

	SELECT ?k ?l WHERE{
    ?x rdf:type ft:Countries;
       rdfs:label `+'"'+country+'"'+`.
    ?h ft:isFootballLeagueOf ?x;
       rdfs:label ?k;
       ft:bestFootballClub ?g.
    ?g rdfs:label ?l.
    
	}`; return queryAMS;
};

function query3(){
queryTUR = 
	`PREFIX ft: <http://www.semanticweb.org/jespe/football#> 
	PREFIX spif: <http://spinrdf.org/spif#> 
	PREFIX dbo: <http://dbpedia.org/ontology/> 
	PREFIX dbr: <http://dbpedia.org/resource/> 
	PREFIX dbp: <http://dbpedia.org/property/> 
	PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> 
	PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#> 
	PREFIX xsd: <http://www.w3.org/2001/XMLSchema#> 
	PREFIX sesame: <http://www.openrdf.org/schema/sesame#> 
	PREFIX owl: <http://www.w3.org/2002/07/owl#> 
	PREFIX fn: <http://www.w3.org/2005/xpath-functions#> 

	SELECT ?x WHERE{
    ?p rdf:type ft:Countries;
       rdfs:label `+'"'+country+'"'+`;
       ft:bestDomestClub ?j.
    ?j rdfs:label ?x.
	}`;
	return queryTUR;
};

var endpoint = "http://192.168.16.101:7200/repositories/Final_Project";

function mainCtrl($scope, $http){

	$scope.getTeams = function(){
		var newprod = "";
		$scope.myDisplayMessage = " You choose to get the football facts of "+country;
		$scope.mySparqlEndpoint = endpoint;
		$scope.mySparqlQuery = encodeURI(query1()).replace(/#/g, '%23');

		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {

			// now iterate on the results
			angular.forEach(data.results.bindings, function(val) {
				newprod += val.teamlabel.value + '<br>';
			league = val.leaguelabel.value;
			document.getElementById('countryimage').innerHTML = "";
			document.getElementById("league").innerHTML = '<button class="imagebut" onclick="getImage()">' +league +'</button>';
			document.getElementById("team").innerHTML = newprod;
			});
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

	};
	
	$scope.getLeagueTeam = function(){
		var leagueteam = "";
		$scope.mySparqlEndpoint = endpoint;
		$scope.mySparqlQuery = encodeURI(query2()).replace(/#/g, '%23');
		console.log("TEST");
		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {

			// now iterate on the results
			angular.forEach(data.results.bindings, function(val) {
				leagueteam += val.l.value;
			document.getElementById('leagueteam').innerHTML = "";
			document.getElementById("leagueclub").innerHTML ='<button class="imagebut" onclick="getteamImage()">' +leagueteam +'</button>';
			});
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

	};

	$scope.getDomTeam = function(){
		var domestteam = "";
		$scope.mySparqlEndpoint = endpoint;
		$scope.mySparqlQuery = encodeURI(query3()).replace(/#/g, '%23');

		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {
			// now iterate on the results
			document.getElementById("domclub").innerHTML = "No data available!";
			angular.forEach(data.results.bindings, function(val) {
				domestteam += val.x.value + '<br>';
			document.getElementById("domclub").innerHTML = domestteam;
			});
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

	};

	$scope.loadFunctions = function(){
		$scope.getTeams();
		$scope.getLeagueTeam();
		$scope.getDomTeam();

	}

}

